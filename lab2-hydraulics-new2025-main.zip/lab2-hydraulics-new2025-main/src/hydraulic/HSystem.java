package hydraulic;

import java.util.Arrays;

/**
 * Main class that acts as a container of the elements for
 * the simulation of a hydraulic system 
 */
public class HSystem {
	private static final int MAX_ELEMENTS = 100;
	private Element[] elements = new Element[10];
	private int next;

	// R1
	/**
	 * Adds a new element to the system
	 * @param elem the new element to be added to the system
	 */
	public void addElement(Element elem){
		if(next == MAX_ELEMENTS) {
			throw new IllegalStateException("Maximum number of elements reached");
		}
		if(next == elements.length){
			int newSize = Math.min(elements.length * 2, MAX_ELEMENTS);
			elements = Arrays.copyOf(elements, newSize);
		}
		elements[next++] = elem;
	}
	
	/**
	 * Returns the elements added so far to the system
	 * @return an array of elements whose length is equal to 
	 *         the number of added elements
	 */
	public Element[] getElements(){
		return Arrays.copyOf(elements, next);
	}

	/**
	 * Returns the number of elements added so far to the system
	 * @return number of elements
	 */
	public int size() {
		return next;
	}

	// R4
	/**
	 * Starts the simulation of the system
	 */
	public void simulate(SimulationObserver observer){
		simulate(observer,false);
	}

	// R6
	/**
	 * Prints the layout of the system starting at each Source
	 */
	public String layout(){
		StringBuffer res = new StringBuffer();
		for(Element e : elements){
			if( e instanceof Source){
				e.layout("", res);
			}
		}
		return res.toString();
	}

	// R7
	/**
	 * Deletes a previously added element with the given name from the system
	 */
	public boolean deleteElement(String name) {
		for(Element current : elements){
			if(current != null && current.getName().equals(name)){
				Element output= null;
				if( current instanceof Split ){
					int count = 0;
					for(Element e : current.getOutputs()){
						if(e != null){
							count++;
							output = e;
						}
					}
					if(count > 1){
						return false;
					}
				}else{
					output = current.getOutput();
				}

				Element input = current.getInput();
				if(input != null) {
					input.replaceWith(current, output);
				} else {
					if(output != null) output.setInput(null);
				}
				remove(current);
				break;
			}
		}
		return true;
	}

	private void remove(Element e){
		boolean found = false;
		for(int i = 0; i < next - 1; ++i){
			if(elements[i] == e){
				found = true;
			}
			if(found){
				elements[i] = elements[i + 1];
			}
		}
		elements[next - 1] = null;
		next--;
	}

	// R8
	/**
	 * Starts the simulation of the system; if {@code enableMaxFlowCheck} is {@code true},
	 * checks also the elements maximum flows against the input flow
	 */
	public void simulate(SimulationObserver observer, boolean enableMaxFlowCheck) {
		for(Element e : elements){
			if(e instanceof Source){
				e.simulate(observer, SimulationObserver.NO_FLOW, enableMaxFlowCheck);
			}
		}
	}

	public static HBuilder build() {
		return new HBuilder();
	}
}