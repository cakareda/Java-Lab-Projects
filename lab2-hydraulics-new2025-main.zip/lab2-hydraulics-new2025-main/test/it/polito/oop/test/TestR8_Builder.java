package it.polito.oop.test;

import hydraulic.*;
import static org.junit.Assert.*;

import org.junit.Test;


public class TestR8_Builder {

	@Test
	public void testBuildSource(){
		HSystem s = HSystem.build().addSource("Src 1").complete();
				
		Element[] elements = s.getElements();
		
		assertNotNull(elements);
		assertEquals("There shoudl be one element;", 1, elements.length);
		assertEquals("Wrong element;", "Src 1", elements[0].getName());
	}

	@Test
	public void testConnections(){
		HSystem s = HSystem.build().
			addSource("Src").
			linkToTap("Tap").
			linkToSink("Sink").
			complete();

		Element[] elements = s.getElements();
	
		assertNotNull(elements);
		assertEquals("Wrong number of elements;", 3, elements.length);
		Element src = elements[0];
		assertEquals("Wrong element;", "Src", src.getName());

		Element tap = src.getOutput();
		assertNotNull("Missing element", tap);
		assertEquals("Wrong element;", "Tap", tap.getName());

		
		Element sink = tap.getOutput();
		assertNotNull("Missing element", sink);
		assertEquals("Wrong element;", "Sink", sink.getName());
	}

	@Test
	public void testSplit(){
		HSystem s = HSystem.build().
		addSource("Src").
		linkToSplit("T").withOutputs().
			linkToSink("Sink 1").
			then().linkToSink("Sink 2").
		complete();
		
		Element[] elements = s.getElements();
	
		assertNotNull(elements);
		assertEquals("Wrong number of elements;", 4, elements.length);
		Element src = elements[0];
		assertEquals("Wrong element;", "Src", src.getName());

		Element split = src.getOutput();

		Element[] out = split.getOutputs();
		
		assertNotNull("Missing outputs for the split",out);
		assertEquals("Wrong number of outputs", 2, out.length);
		assertNotNull("Missing output 0 for Split", out[0]);
		assertEquals("Wrong output 0 for Split", "Sink 1", out[0].getName());
		assertNotNull("Missing output 1 for Split", out[1]);
		assertEquals("Wrong output 1 for Split", "Sink 2", out[1].getName());
	}

	@Test
	public void testSplitSplit(){
		HSystem s = HSystem.build().
		addSource("Src").
		linkToSplit("T").withOutputs().
			linkToSink("Sink 1").
			then().linkToSplit("T2").withOutputs().
				linkToSink("Sink 2").
				then().linkToSink("Sink 3").
				done().
			done().
		complete();
		
		Element[] elements = s.getElements();
	
		assertNotNull(elements);
		assertEquals("Wrong number of elements;", 6, elements.length);
		Element src = elements[0];
		assertEquals("Wrong element;", "Src", src.getName());

		Element split = src.getOutput();

		Element[] out = split.getOutputs();
		
		assertNotNull("Missing outputs for the split",out);
		assertEquals("Wrong number of outputs", 2, out.length);
		assertNotNull("Missing output 0 for Split", out[0]);
		assertEquals("Wrong output 0 for Split", "Sink 1", out[0].getName());
		assertNotNull("Missing output 1 for Split", out[1]);
		assertEquals("Wrong output 1 for Split", "T2", out[1].getName());

		out = out[1].getOutputs();
		assertNotNull("Missing outputs for the nested split",out);
		assertNotNull("Missing output 1 for Split", out[1]);
		assertEquals("Wrong output for nested Split;", "Sink 3", out[1].getName());
	}

	@Test
	public void testSplitTapTap(){
		HSystem s = HSystem.build().
		addSource("Src").
		linkToSplit("T").withOutputs().
			linkToTap("Tap 1").linkToTap("Tap 2").linkToSink("Sink 1").
			then().linkToTap("Tap 3").linkToTap("Tap 4").linkToSink("Sink 2").
			done().
		complete();
		
		Element[] elements = s.getElements();
	
		assertNotNull(elements);
		assertEquals("Wrong number of elements;", 8, elements.length);
		Element src = elements[0];
		assertEquals("Wrong element;", "Src", src.getName());

		Element split = src.getOutput();

		Element[] out = split.getOutputs();
		
		assertNotNull("Missing outputs for the split",out);
		assertEquals("Wrong number of outputs", 2, out.length);
		assertNotNull("Missing output 0 for Split", out[0]);
		assertEquals("Wrong output 0 for Split", "Tap 1", out[0].getName());
		assertNotNull("Missing output 1 for Split", out[1]);
		assertEquals("Wrong output 1 for Split", "Tap 3", out[1].getName());

		assertNotNull("Missing outputs for the sequence of taps",out[0].getOutput());
		assertNotNull("Missing outputs for the sequence of taps",out[1].getOutput());
		assertEquals("Wrong output for nested Split;", "Tap 4", out[1].getOutput().getName());
		assertNotNull("Missing outputs for the sequence of taps",out[1].getOutput().getOutput());
		assertEquals("Wrong output for nested Split;", "Sink 2", out[1].getOutput().getOutput().getName());
	}


	@Test
	public void testSimulate(){
		double flow = 100.0;
		
		HSystem s = HSystem.build().
		addSource("Src").withFlow(flow).
		linkToSplit("T").withOutputs().
			linkToSink("Sink 1").
			then().linkToSink("Sink 2").
		complete();
		
		
		StoreObserver obs = new StoreObserver();
		s.simulate(obs);
		
		assertTrue("There was not simulation notification for element T",obs.contains("T"));
		double[] splitOut = obs.outFlowsOf("T");

		assertEquals("There should be two outputs for the T split",2,splitOut.length);
		assertEquals("Wrong outputs for the T split",50.0,splitOut[0],0.01);
		assertEquals("Wrong outputs for the T split",50.0,splitOut[1],0.01);
		assertEquals("Wrong input flow of 'Sink 1'", 50, obs.inFlowOf("Sink 1"), 0.01);
		assertEquals("Wrong input flow of 'Sink 2'", 50, obs.inFlowOf("Sink 2"), 0.01);
	}

	@Test
	public void testSimulateTap(){
		double flow = 100.0;
		
		HSystem s = HSystem.build().
		addSource("Src").withFlow(flow).
		linkToTap("Tap").open().
		linkToSink("Sink").
		complete();
		
		
		StoreObserver obs = new StoreObserver();
		s.simulate(obs);
		
		assertTrue("There was not simulation notification for element T",obs.contains("Tap"));
		double[] splitOut = obs.outFlowsOf("Tap");

		assertEquals("There should be two outputs for the T split",1,splitOut.length);
		assertEquals("Wrong outputs for the T split",flow,splitOut[0],0.01);
		assertEquals("Wrong input flow of 'Sink 1'", flow, obs.inFlowOf("Sink"), 0.01);
	}

	@Test
	public void testSimulateTapClose(){
		double flow = 100.0;
		
		HSystem s = HSystem.build().
		addSource("Src").withFlow(flow).
		linkToTap("Tap").closed().
		linkToSink("Sink").
		complete();
		
		
		StoreObserver obs = new StoreObserver();
		s.simulate(obs);
		
		assertTrue("There was not simulation notification for element T",obs.contains("Tap"));
		double[] splitOut = obs.outFlowsOf("Tap");

		assertEquals("There should be two outputs for the T split",1,splitOut.length);
		assertEquals("Wrong outputs for the T split", 0.0, splitOut[0],0.01);
		assertEquals("Wrong input flow of 'Sink 1'", 0.0, obs.inFlowOf("Sink"), 0.01);
	}

	@Test
	public void testSimulateMultisplit(){
		double flow = 100.0;
		double[] props = {0.25,0.35,0.40};

		HSystem s = HSystem.build().
		addSource("Src").withFlow(flow).
		linkToMultisplit("MS",3).withPropotions(props).withOutputs().
			linkToSink("S1").
			then().linkToSink("S2").
			then().linkToSink("S3").
		complete();
		
		
		StoreObserver obs = new StoreObserver();
		s.simulate(obs);
				
		assertTrue("Missing simulation trace for element MS",obs.contains("MS"));

		double inTap = obs.inFlowOf("MS");
		double[] outTap = obs.outFlowsOf("MS");
		double inSink = obs.inFlowOf("S3");

		assertEquals("Wrong input flow of 'MS'", flow, inTap, 0.01);
		for(int i=0; i<props.length; ++i)
			assertEquals("Wrong output flow " + i + " of 'MS'", flow*props[i], outTap[i], 0.01);
		assertEquals("Wrong input flow of 'S3'", flow*props[2], inSink, 0.01);
	}

	@Test
	public void testSimulateMultisplitSplit(){
		double flow = 100.0;
		double[] props = {0.25,0.35,0.40};

		HSystem s = HSystem.build().
		addSource("Src").withFlow(flow).
		linkToMultisplit("MS",3).withPropotions(props).withOutputs().
			linkToSplit("T").withOutputs().
				linkToSink("S1").
				then().linkToSink("S2").
				done().
			then().linkToSink("S3").
			then().linkToSink("S4").
		complete();
				
		StoreObserver obs = new StoreObserver();
		s.simulate(obs);
				
		assertTrue("Missing simulation trace for element MS",obs.contains("MS"));

		double inTap = obs.inFlowOf("MS");
		double[] outTap = obs.outFlowsOf("MS");
		double inSink = obs.inFlowOf("S2");

		assertEquals("Wrong input flow of 'MS'", flow, inTap, 0.01);
		for(int i=0; i<props.length; ++i)
			assertEquals("Wrong output flow " + i + " of 'MS'", flow*props[i], outTap[i], 0.01);
		assertEquals("Wrong input flow of 'S2'", flow*props[0]*0.5, inSink, 0.01);
	}

	@Test
	public void testMaxFlow(){
		double flow = 100.0;
		
		HSystem s = HSystem.build().
		addSource("Src").withFlow(flow).
		linkToTap("Tap").open().maxFlow(90.0).
		linkToSink("Sink").maxFlow(90.0).
		complete();
		
		
		StoreObserver obs = new StoreObserver();
		s.simulate(obs, true);
		
		assertEquals("Wrong number of notifications",2,obs.getErrorCount());
		assertTrue("Missing simulation trace for element Tap",obs.containsError("Tap"));

		assertEquals("Wrong max flow of 'Tap'", 90.0, obs.maxFlowOf("Tap"), 0.01);
		assertEquals("Wrong max flow of 'Sink'", 90.0, obs.maxFlowOf("Sink"), 0.01);
	}


}
