package diet;

import java.util.*;

/**
 * Represents a recipe of the diet.
 * 
 * A recipe consists of a set of ingredients that are given amounts of raw materials.
 * The overall nutritional values of a recipe can be computed
 * on the basis of the ingredients' values and are expressed per 100g.
 */
public class Recipe implements NutritionalElement {

    private String name;
    private Food food;
    private Map<NutritionalElement, Double> ingredients = new LinkedHashMap<>();

    public Recipe(String name, Food food) {
        this.name = name;
        this.food = food;
    }

    /**
     * Adds the given quantity of an ingredient to the recipe.
     * The ingredient is a raw material.
     * 
     * @param material the name of the raw material to be used as ingredient
     * @param quantity the amount in grams of the raw material to be used
     * @return the same Recipe object, it allows method chaining.
     */
    public Recipe addIngredient(String material, double quantity) {
        NutritionalElement element = food.getRawMaterial(material);
        if (element != null) {
            ingredients.put(element, quantity);
        }
        return this;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getCalories() {
        return computePer100g(NutritionalValue.CALORIES);
    }

    @Override
    public double getProteins() {
        return computePer100g(NutritionalValue.PROTEINS);
    }

    @Override
    public double getCarbs() {
        return computePer100g(NutritionalValue.CARBS);
    }

    @Override
    public double getFat() {
        return computePer100g(NutritionalValue.FAT);
    }

    /**
     * Indicates whether the nutritional values returned by the other methods
     * refer to a conventional 100g quantity of nutritional element,
     * or to a unit of element.
     * 
     * For the {@link Recipe} class it must always return {@code true}:
     * a recipe expresses nutritional values per 100g.
     * 
     * @return boolean indicator
     */
    @Override
    public boolean per100g() {
        return true;
    }

    /**
     * Calculates the nutritional value for a given type (calories, proteins, carbs, or fat)
     * based on the ingredients and their respective quantities.
     * 
     * @param type The type of nutritional value to compute.
     * @return The computed nutritional value for the recipe.
     */
    private double computePer100g(NutritionalValue type) {
        double totalWeight = 0.0;
        double totalValue = 0.0;

        for (Map.Entry<NutritionalElement, Double> entry : ingredients.entrySet()) {
            NutritionalElement ingredient = entry.getKey();
            double weight = entry.getValue();
            totalWeight += weight;

            switch (type) {
                case CALORIES:
                    totalValue += ingredient.getCalories() * weight / 100.0;
                    break;
                case PROTEINS:
                    totalValue += ingredient.getProteins() * weight / 100.0;
                    break;
                case CARBS:
                    totalValue += ingredient.getCarbs() * weight / 100.0;
                    break;
                case FAT:
                    totalValue += ingredient.getFat() * weight / 100.0;
                    break;
            }
        }

        if (totalWeight == 0.0) return 0.0;

        // Scale to 100g portion
        return (totalValue / totalWeight) * 100.0;
    }

    // Enum to represent the different nutritional values
    private enum NutritionalValue {
        CALORIES,
        PROTEINS,
        CARBS,
        FAT
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<NutritionalElement, Double> entry : ingredients.entrySet()) {
            sb.append(entry.getKey().getName())
              .append(" - ")
              .append(entry.getValue())
              .append("g\n");
        }
        return sb.toString().trim(); // remove trailing newline
    }
}
