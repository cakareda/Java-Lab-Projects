package diet;

public class User {
    private String firstName;  // First name of the user
    private String lastName;   // Last name of the user
    private String email;      // Email of the user
    private String phone;      // Phone number of the user

    /**
     * Constructor to initialize the user object with first name, last name, email, and phone number.
     * @param firstName The first name of the user
     * @param lastName The last name of the user
     * @param email The email address of the user
     * @param phone The phone number of the user
     */
    public User(String firstName, String lastName, String email, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
    }

    /**
     * Retrieves the first name of the user.
     * @return First name of the user
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Retrieves the last name of the user.
     * @return Last name of the user
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Retrieves the email of the user.
     * @return Email address of the user
     */
    public String getEmail() {
        return email;
    }

    /**
     * Retrieves the phone number of the user.
     * @return Phone number of the user
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Sets a new email address for the user.
     * @param email The new email address
     */
    public void SetEmail(String email) {
        this.email = email;
    }

    /**
     * Sets a new phone number for the user.
     * @param phone The new phone number
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Provides a string representation of the user.
     * The format is: "firstName lastName"
     * @return A string representation of the user
     */
    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}
