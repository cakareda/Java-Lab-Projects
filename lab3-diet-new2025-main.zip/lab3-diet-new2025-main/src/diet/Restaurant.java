package diet;

import diet.Order.OrderStatus;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Represents a restaurant class with given opening times and a set of menus.
 */
public class Restaurant {

    private String name;
    private Map<String, Menu> menus = new HashMap<>();
    private List<String[]> hours = new ArrayList<>();
    private List<Order> orders = new ArrayList<>();

    /**
     * Constructor for the Restaurant
     *
     * @param name the name of the restaurant
     * @param food reference to the Food object to access recipes and products
     */
    public Restaurant(String name, Food food) {
        this.name = name;
    }

    /**
     * Retrieves the name of the restaurant.
     *
     * @return name of the restaurant
     */
    public String getName() {
        return name;
    }

    /**
     * Define opening times.
     * Accepts an array of strings (even number of elements) in the format {@code "HH:MM"},
     * so that the closing hours follow the opening hours
     * (e.g., for a restaurant opened from 8:15 until 14:00 and from 19:00 until 00:00,
     * arguments would be {@code "08:15", "14:00", "19:00", "00:00"}).
     *
     * @param hm sequence of opening and closing times
     */
    public void setHours(String... hm) {
        if (hm.length % 2 == 0) {
            for (int i = 0; i < hm.length; i += 2) {
                hours.add(new String[]{hm[i], hm[i + 1]});
            }
        } else {
            throw new IllegalArgumentException("The hours array must have an even number of elements.");
        }
    }

    /**
     * Checks whether the restaurant is open at the given time.
     *
     * @param time time to check
     * @return {@code true} is the restaurant is open at that time
     */
    public boolean isOpenAt(String time) {
        for (String[] timeRange : hours) {
            String openTime = timeRange[0];
            String closeTime = timeRange[1];

            if (isTimeBetween(time, openTime, closeTime)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Helper method to check if the time is between two other times.
     *
     * @param time the current time
     * @param startTime the opening time
     * @param endTime the closing time
     * @return true if the time is between startTime and endTime, false otherwise
     */
    private boolean isTimeBetween(String time, String startTime, String endTime) {
        return time.compareTo(startTime) >= 0 && time.compareTo(endTime) < 0;
    }

    /**
     * Adds a menu to the list of menus offered by the restaurant
     *
     * @param menu the menu
     */
    public void addMenu(Menu menu) {
        menus.put(menu.getName(), menu);
    }

    /**
     * Gets the restaurant menu with the given name
     *
     * @param name name of the required menu
     * @return menu with the given name
     */
    public Menu getMenu(String name) {
        return menus.get(name);
    }

    /**
     * Retrieve all orders with a given status with all the relative details in text format.
     *
     * The list is sorted by name of restaurant, name of the customer, and delivery time.
     *
     * @param status the status to be matched
     * @return textual representation of orders
     */
    public String ordersWithStatus(OrderStatus status) {
        // Filter orders matching the status and sort them.
        List<Order> filteredOrders = orders.stream()
            .filter(order -> order.getStatus() == status)
            .sorted(Comparator.comparing((Order o) -> o.getRestaurant().getName())
                    .thenComparing(o -> o.getUser().toString())
                    .thenComparing(Order::getDeliveryTime))
            .collect(Collectors.toList());
        
        StringBuilder result = new StringBuilder();
        for (Order order : filteredOrders) {
            result.append(order).append("\n");
        }
        return result.toString().trim();
    }

    /**
     * Add an order to the restaurant's list of orders
     *
     * @param order the order to be added
     */
    public void addOrder(Order order) {
        orders.add(order);
    }

    /**
     * Retrieves the opening hours for the restaurant.
     *
     * @return list of hours (start and end time pairs)
     */
    public List<String[]> getHours() {
        return hours;
    }
}
