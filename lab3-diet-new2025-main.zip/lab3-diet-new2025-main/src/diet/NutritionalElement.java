package diet;

/**
 * Interface representing nutritional elements (e.g., recipes, products).
 * Provides methods to get the nutritional information for the element.
 */
public interface NutritionalElement {

    /**
     * Get the name of the nutritional element.
     */
    String getName();

    /**
     * Get the total calories for the nutritional element.
     */
    double getCalories();

    /**
     * Get the total proteins for the nutritional element.
     */
    double getProteins();

    /**
     * Get the total carbohydrates for the nutritional element.
     */
    double getCarbs();

    /**
     * Get the total fats for the nutritional element.
     */
    double getFat();

    /**
     * Indicates if the nutritional values refer to the element per 100g or per unit.
     * 
     * @return true if the values are per 100g, false if they are per unit.
     */
    boolean per100g();
}
