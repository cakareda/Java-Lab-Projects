package diet;

import java.util.*;

/**
 * Represents a takeaway restaurant chain.
 * It allows managing restaurants, customers, and orders.
 */
public class Takeaway {

    private Map<String, Restaurant> restaurants = new HashMap<>();
    private Map<String, Customer> customers = new HashMap<>();
    private Food food;
    private String normalizeTime(String time) {
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        return String.format("%02d:%02d", hours, minutes);
    }
    
    /**
     * Constructor
     * @param food the reference {@link Food} object with materials and products info.
     */
    public Takeaway(Food food) {
        this.food = food;
    }

    /**
     * Creates a new restaurant with a given name
     *
     * @param restaurantName name of the restaurant
     * @return the new restaurant
     */
    public Restaurant addRestaurant(String restaurantName) {
        Restaurant restaurant = new Restaurant(restaurantName, food);
        restaurants.put(restaurantName, restaurant);
        return restaurant;
    }

    /**
     * Retrieves the names of all restaurants
     *
     * @return collection of restaurant names
     */
    public Collection<String> restaurants() {
        return restaurants.keySet();
    }

    /**
     * Creates a new customer for the takeaway
     * @param firstName first name of the customer
     * @param lastName last name of the customer
     * @param email email of the customer
     * @param phoneNumber mobile phone number
     *
     * @return the object representing the newly created customer
     */
    public Customer registerCustomer(String firstName, String lastName, String email, String phoneNumber) {
    // Create a new Customer object for each call
    Customer customer = new Customer(firstName, lastName, email, phoneNumber);

    // Store the customer, even if the email already exists
    customers.put(email + System.nanoTime(), customer); // Use a unique key by appending a timestamp

    return customer;
}

    /**
     * Retrieves all registered customers
     *
     * @return sorted collection of customers by their email
     */
    public Collection<Customer> customers() {
        TreeSet<Customer> sortedCustomers = new TreeSet<>(new Comparator<Customer>() {
            @Override
            public int compare(Customer c1, Customer c2) {
                // First compare by last name, then by first name
                int lastNameComparison = c1.getLastName().compareTo(c2.getLastName());
                if (lastNameComparison != 0) {
                    return lastNameComparison;
                }
                return c1.getFirstName().compareTo(c2.getFirstName());
            }
        });
        sortedCustomers.addAll(customers.values());
        return sortedCustomers;
    }
    

    /**
     * Creates a new order for the chain.
     *
     * @param customer customer issuing the order
     * @param restaurantName name of the restaurant that will take the order
     * @param time time of desired delivery in "HH:MM" format
     * @return order object
     */
    public Order createOrder(User customer, String restaurantName, String time) {
        Restaurant restaurant = restaurants.get(restaurantName);
        if (restaurant != null) {
            String adjustedTime = normalizeTime(time);
            if (!restaurant.isOpenAt(adjustedTime)) {
                adjustedTime = normalizeTime(getNextOpeningTime(restaurant, adjustedTime));
            }
            Order order = new Order(customer, restaurant, adjustedTime);
            restaurant.addOrder(order);
            return order;
        }
        return null;
    }
    

    /**
     * Find the next opening time for a restaurant given a requested time.
     *
     * @param restaurant the restaurant
     * @param time the requested time in "HH:MM" format
     * @return the next available opening time in "HH:MM" format.
     */
    private String getNextOpeningTime(Restaurant restaurant, String time) {
        int requestedMinutes = toMinutes(time);
        String nextOpening = null;
        // Retrieve the list of opening hour intervals
        List<String[]> intervals = restaurant.getHours();
        for (String[] interval : intervals) {
            int startMinutes = toMinutes(interval[0]);
            // Find first interval with opening time greater than or equal to requested time
            if (startMinutes >= requestedMinutes) {
                nextOpening = interval[0];
                break;
            }
        }
        // If no opening interval starts after the requested time, select the first opening time of next day
        if (nextOpening == null && !intervals.isEmpty()) {
            nextOpening = intervals.get(0)[0];
        }
        return nextOpening;
    }

    /**
     * Converts a time in "HH:MM" format to the total minutes from midnight.
     *
     * @param time time in "HH:MM" format
     * @return total minutes from midnight
     */
    private int toMinutes(String time) {
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        return hours * 60 + minutes;
    }

    /**
     * Find all restaurants that are open at a given time.
     *
     * The returned collection is sorted alphabetically by the restaurant name.
     *
     * @param time the time with format {@code "HH:MM"}
     * @return the sorted collection of restaurants
     */
    public Collection<Restaurant> openRestaurants(String time) {
        List<Restaurant> openRestaurants = new ArrayList<>();
        for (Restaurant restaurant : restaurants.values()) {
            if (restaurant.isOpenAt(time)) {
                openRestaurants.add(restaurant);
            }
        }
        // Sort alphabetically by restaurant name.
        openRestaurants.sort(Comparator.comparing(Restaurant::getName));
        return openRestaurants;
    }
}
