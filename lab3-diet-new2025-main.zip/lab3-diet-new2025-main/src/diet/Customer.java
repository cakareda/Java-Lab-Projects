package diet;

public class Customer extends User implements Comparable<Customer> {

    /**
     * Constructor for Customer.
     *
     * @param firstName first name of the customer
     * @param lastName last name of the customer
     * @param email email of the customer
     * @param phone phone number of the customer
     */
    public Customer(String firstName, String lastName, String email, String phone) {
        super(firstName, lastName, email, phone);
    }

    /**
     * Implement the compareTo method to compare customers by their email.
     *
     * @param other the other customer to compare to
     * @return comparison result based on email lexicographically
     */
    @Override
    public int compareTo(Customer other) {
        return getEmail().compareTo(other.getEmail());
    }
}
