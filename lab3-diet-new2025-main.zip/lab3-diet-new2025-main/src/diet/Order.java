package diet;

import java.util.*;

/**
 * Represents an order issued by a {@link User} for a {@link Restaurant}.
 *
 * When an order is printed to a string it should look like:
 * <pre>
 *  RESTAURANT_NAME, USER_FIRST_NAME USER_LAST_NAME : (DELIVERY_HH:MM):
 *      MENU_NAME_1->MENU_QUANTITY_1
 *      ...
 *      MENU_NAME_k->MENU_QUANTITY_k
 * </pre>
 */
public class Order {

    /**
     * Possible order statuses
     */
    public enum OrderStatus {
        ORDERED, READY, DELIVERED
    }

    /**
     * Accepted payment methods
     */
    public enum PaymentMethod {
        PAID, CASH, CARD
    }

    private User user;
    private Restaurant restaurant;
    private String deliveryTime;
    private OrderStatus status;
    private PaymentMethod paymentMethod;
    
    // Map to store menu name and its quantity.
    private Map<String, Integer> menus;

    /**
     * Constructor for Order
     * @param user the user placing the order
     * @param restaurant the restaurant receiving the order
     * @param deliveryTime the desired delivery time in "HH:MM" format
     */
    public Order(User user, Restaurant restaurant, String deliveryTime) {
        this.user = user;
        this.restaurant = restaurant;
        this.deliveryTime = deliveryTime;
        this.status = OrderStatus.ORDERED; // Default status
        // Set default payment method to CASH
        this.paymentMethod = PaymentMethod.CASH;
        this.menus = new HashMap<>();
    }

    /**
     * Set payment method
     * @param pm the payment method
     */
    public void setPaymentMethod(PaymentMethod pm) {
        this.paymentMethod = pm;
    }

    /**
     * Retrieves current payment method
     * @return the current method
     */
    public PaymentMethod getPaymentMethod() {
        return this.paymentMethod;
    }

    /**
     * Set the new status for the order
     * @param os new status
     */
    public void setStatus(OrderStatus os) {
        this.status = os;
    }

    /**
     * Retrieves the current status of the order.
     *
     * @return current status
     */
    public OrderStatus getStatus() {
        return this.status;
    }

    /**
     * Add a new menu to the order with a given quantity.
     * If the menu is added more than once, the quantity is overwritten.
     *
     * @param menu the name of the menu to be added
     * @param quantity quantity of the menu
     * @return the order itself (allows method chaining)
     */
    public Order addMenus(String menu, int quantity) {
        menus.put(menu, quantity);
        return this;
    }

    /**
     * Returns the textual representation of the order.
     * Format:
     * <pre>
     *  RESTAURANT_NAME, USER_FIRST_NAME USER_LAST_NAME : (DELIVERY_HH:MM):
     *      MENU_NAME_1->MENU_QUANTITY_1
     *      ...
     *      MENU_NAME_k->MENU_QUANTITY_k
     * </pre>
     *
     * @return String representation of the order.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(restaurant.getName())
          .append(", ")
          .append(user.getFirstName())
          .append(" ")
          .append(user.getLastName())
          .append(" : (")
          .append(deliveryTime)
          .append("):\n");

        // Sort menu names alphabetically.
        List<String> menuNames = new ArrayList<>(menus.keySet());
        Collections.sort(menuNames);
        for (String menu : menuNames) {
            sb.append("\t")
              .append(menu)
              .append("->")
              .append(menus.get(menu))
              .append("\n");
        }
        return sb.toString().trim();
    }
    
    /**
     * Retrieves the delivery time of the order.
     *
     * @return the delivery time in "HH:MM"
     */
    public String getDeliveryTime() {
        return this.deliveryTime;
    }
    
    /**
     * Retrieves the user who placed the order.
     *
     * @return the user
     */
    public User getUser() {
        return this.user;
    }
    
    /**
     * Retrieves the restaurant for the order.
     *
     * @return the restaurant
     */
    public Restaurant getRestaurant() {
        return this.restaurant;
    }
}
