package mountainhuts;

public class AltitudeRange {

    private final Integer max;
    private final Integer min;
    
    public AltitudeRange(String range) {
        max = Integer.parseInt(range.split("-")[1]);
        min = Integer.parseInt(range.split("-")[0]);
        System.out.println("Created AltitudeRange: " + this.toString());
    }

    public boolean contains(Integer value) {
        return min < value && value <= max;
    }

    public String toString() {
        return min + "-" + (max==Integer.MAX_VALUE?"INF":max);
    }
}
