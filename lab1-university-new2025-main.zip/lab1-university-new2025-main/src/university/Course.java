package university;

public class Course {
    private int code;
    private String title;
    private String teacher;

    public Course(int code, String title, String teacher) {
        this.code = code;
        this.title = title;
        this.teacher = teacher;
    }

    public String getTitle() {
        return title;
    }

    public int getCode() {
        return code;
    }

    public String getInfo() {
        return code + "," + title + "," + teacher;
    }
}