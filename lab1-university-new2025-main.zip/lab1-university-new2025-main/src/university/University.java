package university;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a university education system.
 * 
 * It manages students and courses.
 *
 */
public class University {

    // Logger setup with ConsoleHandler explicitly
    public static final Logger logger = Logger.getLogger("University");

    static {
        // Create a ConsoleHandler and set its level to INFO
        ConsoleHandler consoleHandler = new ConsoleHandler();
        consoleHandler.setLevel(Level.INFO);

        // Add the ConsoleHandler to the logger
        logger.addHandler(consoleHandler);

        // Set the default level of the logger
        logger.setLevel(Level.INFO);
    }

    private String name;
    private String rectorFirst;
    private String rectorLast;
    private List<Student> students = new ArrayList<>();
    private List<Course> courses = new ArrayList<>();
    private List<Exam> exams = new ArrayList<>();
    private int nextStudentId = 10000;
    private int nextCourseCode = 10;

    /**
     * Constructor
     * @param name name of the university
     */
    public University(String name) {
        this.name = name;
    }

    /**
     * Getter for the name of the university
     * 
     * @return name of university
     */
    public String getName() {
        return name;
    }

    /**
     * Defines the rector for the university
     * 
     * @param first first name of the rector
     * @param last last name of the rector
     */
    public void setRector(String first, String last) {
        rectorFirst = first;
        rectorLast = last;
    }

    /**
     * Retrieves the rector of the university with the format "First Last"
     * 
     * @return name of the rector
     */
    public String getRector() {
        return rectorFirst + " " + rectorLast;
    }

    /**
     * Enrol a student in the university
     * The university assigns ID numbers progressively from number 10000.
     * 
     * @param first first name of the student
     * @param last last name of the student
     * 
     * @return unique ID of the newly enrolled student
     */
    public int enroll(String first, String last) {
        Student student = new Student(nextStudentId++, first, last);
        students.add(student);
        logger.info("Enrolled student: " + String.valueOf(student.getName()));
        return student.getId();
    }
	
	/**
	 * Retrieves the information for a given student.
	 * The university assigns IDs progressively starting from 10000
	 * 
	 * @param id the ID of the student
	 * 
	 * @return information about the student
	 */
	public String student(int id){
		for (Student student : students) {
            if (student.getId() == id) {
                return student.getName();
            }
        }
        return "Student not found";
	}
	
// R3
	/**
	 * Activates a new course with the given teacher
	 * Course codes are assigned progressively starting from 10.
	 * 
	 * @param title title of the course
	 * @param teacher name of the teacher
	 * 
	 * @return the unique code assigned to the course
	 */
	public int activate(String title, String teacher){
		Course course = new Course(nextCourseCode++, title, teacher);
        courses.add(course);
        logger.info("Activated course: " + String.valueOf(course.getInfo()));
        return course.getCode();
	}
	
	/**
	 * Retrieve the information for a given course.
	 * 
	 * The course information is formatted as a string containing 
	 * code, title, and teacher separated by commas, 
	 * e.g., {@code "10,Object Oriented Programming,James Gosling"}.
	 * 
	 * @param code unique code of the course
	 * 
	 * @return information about the course
	 */
	public String course(int code){
		for (Course course : courses) {
            if (course.getCode() == code) {
                return course.getInfo();
            }
        }
        return "Course not found";
	}
	
// R4
/**
 * Register a student to attend a course
 * @param studentID id of the student
 * @param courseCode id of the course
 */
public void register(int studentID, int courseCode){
    Student student = null;
    Course course = null;
    for (Student s : students) {
        if (s.getId() == studentID) {
            student = s;
            break;
        }
    }
    for (Course c : courses) {
        if (c.getCode() == courseCode) {
            course = c;
            break;
        }
    }
    if (student != null && course != null) {
        student.enroll(course);
        // Updated log message to include student ID
        logger.info(student.getName() + " (ID: " + student.getId() + ") registered for " + course.getInfo());
    }
}
	
	/**
	 * Retrieve a list of attendees.
	 * 
	 * The students appear one per row (rows end with `'\n'`) 
	 * and each row is formatted as describe in in method {@link #student}
	 * 
	 * @param courseCode unique id of the course
	 * @return list of attendees separated by "\n"
	 */
	public String listAttendees(int courseCode){
		StringBuilder attendees = new StringBuilder();
        for (Student student : students) {
            for (Course course : student.getCourses()) {
                if (course.getCode() == courseCode) {
                    attendees.append(student.getName()).append("\n");
                }
            }
        }
        return attendees.toString();
	}

	/**
	 * Retrieves the study plan for a student.
	 * 
	 * The study plan is reported as a string having
	 * one course per line (i.e. separated by '\n').
	 * The courses are formatted as describe in method {@link #course}
	 * 
	 * @param studentID id of the student
	 * 
	 * @return the list of courses the student is registered for
	 */
	public String studyPlan(int studentID){
		StringBuilder studyPlan = new StringBuilder();
        for (Student student : students) {
            if (student.getId() == studentID) {
                for (Course course : student.getCourses()) {
                    studyPlan.append(course.getInfo()).append("\n");
                }
                break;
            }
        }
        return studyPlan.toString();
	}

// R5
	/**
	 * records the grade (integer 0-30) for an exam can 
	 * 
	 * @param studentId the ID of the student
	 * @param courseID	course code 
	 * @param grade		grade ( 0-30)
	 */
	public void exam(int studentId, int courseID, int grade) {
		Student student = null;
        Course course = null;
        for (Student s : students) {
            if (s.getId() == studentId) {
                student = s;
                break;
            }
        }
        for (Course c : courses) {
            if (c.getCode() == courseID) {
                course = c;
                break;
            }
        }
        if (student != null && course != null) {
            Exam exam = new Exam(student, course, grade);
            exams.add(exam);
            student.addExam(exam);
            logger.info("Recorded exam for " + String.valueOf(student.getName()) + " in " + String.valueOf(course.getInfo()) + " with grade " + grade);
        }
	}

	/**
	 * Computes the average grade for a student and formats it as a string
	 * using the following format 
	 * 
	 * {@code "Student STUDENT_ID : AVG_GRADE"}. 
	 * 
	 * If the student has no exam recorded the method
	 * returns {@code "Student STUDENT_ID hasn't taken any exams"}.
	 * 
	 * @param studentId the ID of the student
	 * @return the average grade formatted as a string.
	 */
	public String studentAvg(int studentId) {
		for (Student student : students) {
            if (student.getId() == studentId) {
                if (student.getExams().isEmpty()) {
                    return "Student " + studentId + " hasn't taken any exams";
                } else {
                    return "Student " + studentId + " : " + student.getAverageGrade();
                }
            }
        }
        return "Student not found";
	}
	
	/**
	 * Computes the average grades of all students that took the exam for a given course.
	 * 
	 * The format is the following: 
	 * {@code "The average for the course COURSE_TITLE is: COURSE_AVG"}.
	 * 
	 * If no student took the exam for that course it returns {@code "No student has taken the exam in COURSE_TITLE"}.
	 * 
	 * @param courseId	course code 
	 * @return the course average formatted as a string
	 */
	public String courseAvg(int courseId) {
		double total = 0;
        int count = 0;
        for (Exam exam : exams) {
            if (exam.getCourse().getCode() == courseId) {
                total += exam.getGrade();
                count++;
            }
        }
		if (count == 0) {
			for (Course course : courses) {
				if (course.getCode() == courseId) {
					return "No student has taken the exam in " + course.getTitle();
				}
			}
			return "No student has taken the exam in this course";
		} else {
			for (Course course : courses) {
				if (course.getCode() == courseId) {
					return "The average for the course " + course.getTitle() + " is: " + total / count;
				}
			}
			return "The average for the course is: " + total / count;
		}
	}
	

// R6
	/**
	 * Retrieve information for the best students to award a price.
	 * 
	 * The students' score is evaluated as the average grade of the exams they've taken. 
	 * To take into account the number of exams taken and not only the grades, 
	 * a special bonus is assigned on top of the average grade: 
	 * the number of taken exams divided by the number of courses the student is enrolled to, multiplied by 10.
	 * The bonus is added to the exam average to compute the student score.
	 * 
	 * The method returns a string with the information about the three students with the highest score. 
	 * The students appear one per row (rows are terminated by a new-line character {@code '\n'}) 
	 * and each one of them is formatted as: {@code "STUDENT_FIRSTNAME STUDENT_LASTNAME : SCORE"}.
	 * 
	 * @return info on the best three students.
	 */
	public String topThreeStudents() {
		students.sort((s1, s2) -> Double.compare(s2.getFinalScore(), s1.getFinalScore()));
		StringBuilder result = new StringBuilder();
		int count = 0;
		for (Student student : students) {
			if (!student.getExams().isEmpty()) {
				result.append(student.getName()).append(" : ").append(student.getFinalScore()).append("\n");
				count++;
				if (count == 3) break;
			}
		}
		return result.toString();
    }

// R7
    /**
     * This field points to the logger for the class that can be used
     * throughout the methods to log the activities.
     */
	
}