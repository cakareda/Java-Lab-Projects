package university;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private int id;
    private String firstName;
    private String lastName;
    private List<Course> courses = new ArrayList<>();
    private List<Exam> exams = new ArrayList<>();

    public Student(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return firstName + " " + lastName;
    }

    public void enroll(Course course) {
        courses.add(course);
    }

    public void addExam(Exam exam) {
        exams.add(exam);
    }

    public List<Course> getCourses() {
        return courses;
    }

    public List<Exam> getExams() {
        return exams;
    }

    public double getAverageGrade() {
        if (exams.isEmpty()) return 0;
        double sum = 0;
        for (Exam exam : exams) {
            sum += exam.getGrade();
        }
        return sum / exams.size();
    }

    public double getBonus() {
        return (double) exams.size() / courses.size() * 10;
    }

    public double getFinalScore() {
        return getAverageGrade() + getBonus();
    }
}