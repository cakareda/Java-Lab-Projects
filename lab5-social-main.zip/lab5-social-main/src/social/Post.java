package social;

import jakarta.persistence.*;
import java.util.UUID;

/**
 * Models a post created by a user.
 */
@Entity
public class Post {

  @Id
  private String id;

  private long timestamp;

  private String content;

  @ManyToOne(fetch = FetchType.EAGER)
  private Person author;

  /**
   * Required by JPA.
   */
  public Post() {}

  /**
   * Creates a post with a unique ID and current timestamp.
   */
  public Post(Person author, String content) {
    this.id = UUID.randomUUID().toString().replace("-", "");
    this.timestamp = System.currentTimeMillis();
    this.content = content;
    this.author = author;
  }

  public String getId() {
    return id;
  }

  public long getTimestamp() {
    return timestamp;
  }

  public String getContent() {
    return content;
  }

  public Person getAuthor() {
    return author;
  }
}
