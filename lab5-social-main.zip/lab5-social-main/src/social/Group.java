package social;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * This class models a group in the social network.
 */
@Entity
@Table(name = "groups") 
public class Group {


  @Id
  private String name;

  @ManyToMany(fetch = FetchType.EAGER)
  @JoinTable(
    name = "group_membership",
    joinColumns = @JoinColumn(name = "group_name"),
    inverseJoinColumns = @JoinColumn(name = "person_code")
  )
  private Set<Person> members = new HashSet<>();

  /**
   * Default constructor required by JPA
   */
  public Group() {}

  /**
   * Creates a new group with a name.
   * 
   * @param name unique group name
   */
  public Group(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setName(String newName) {
    this.name = newName;
  }

  public Set<Person> getMembers() {
    return members;
  }
}
