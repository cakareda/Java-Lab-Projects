package social;

/**
 * Repository for Group entities.
 */
public class GroupRepository extends GenericRepository<Group, String> {

  public GroupRepository() {
    super(Group.class);
  }
}
