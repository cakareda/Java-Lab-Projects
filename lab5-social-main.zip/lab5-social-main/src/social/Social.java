package social;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Facade class for the social network system.
 * 
 */
public class Social {

  private final PersonRepository personRepository = new PersonRepository();
  private final GroupRepository groupRepository = new GroupRepository();
  private final PostRepository postRepository = new PostRepository();
  /**
   * Creates a new account for a person
   * 
   * @param code    nickname of the account
   * @param name    first name
   * @param surname last name
   * @throws PersonExistsException in case of duplicate code
   */
  public void addPerson(String code, String name, String surname) throws PersonExistsException {
    if (personRepository.findById(code).isPresent()) {
      throw new PersonExistsException();
    }
    Person person = new Person(code, name, surname);
    personRepository.save(person);
  }

  /**
   * Retrieves information about the person given their account code.
   * The info consists in name and surname of the person, in order, separated by
   * blanks.
   * 
   * @param code account code
   * @return the information of the person
   * @throws NoSuchCodeException if a person with that code does not exist
   */
  public String getPerson(String code) throws NoSuchCodeException {
    Person person = personRepository.findById(code).orElse(null);
    if (person == null) throw new NoSuchCodeException();
    return person.getCode() + " " + person.getName() + " " + person.getSurname();
  }

  /**
   * Define a friendship relationship between two persons given their codes.
   * <p>
   * Friendship is bidirectional: if person A is adding as friend person B, that means
   * that person B automatically adds as friend person A.
   * 
   * @param codePerson1 first person code
   * @param codePerson2 second person code
   * @throws NoSuchCodeException in case either code does not exist
   */
  public void addFriendship(String code1, String code2) throws NoSuchCodeException {
    Person p1 = personRepository.findById(code1).orElseThrow(NoSuchCodeException::new);
    Person p2 = personRepository.findById(code2).orElseThrow(NoSuchCodeException::new);

    p1.addFriend(p2);

    
    personRepository.save(p1);
    personRepository.save(p2);
  }

  /**
   * Retrieve the collection of their friends given the code of a person.
   *
   * @param codePerson code of the person
   * @return the list of person codes
   * @throws NoSuchCodeException in case the code does not exist
   */
  public Collection<String> listOfFriends(String code) throws NoSuchCodeException {
    Person person = personRepository.findById(code).orElseThrow(NoSuchCodeException::new);
    return person.getFriends().stream()
        .map(Person::getCode)
        .sorted()
        .collect(Collectors.toList());
  }

  /**
   * Creates a new group with the given name
   * 
   * @param groupName name of the group
   * @throws GroupExistsException if a group with given name does not exist
   */
  public void addGroup(String groupName) throws GroupExistsException {
    if (groupRepository.findById(groupName).isPresent()) {
      throw new GroupExistsException();
    }
    groupRepository.save(new Group(groupName));
  }

  /**
   * Deletes the group with the given name
   * 
   * @param groupName name of the group
   * @throws NoSuchCodeException if a group with given name does not exist
   */

  public void updateGroupName(String oldName, String newName)
      throws GroupExistsException, NoSuchCodeException {
    Group group = groupRepository.findById(oldName).orElse(null);
    if (group == null) throw new NoSuchCodeException();
    if (groupRepository.findById(newName).isPresent()) {
      throw new GroupExistsException();
    }

    groupRepository.delete(oldName);
    group.setName(newName);
    groupRepository.save(group);
  }

  public void deleteGroup(String groupName) throws NoSuchCodeException {
    if (!groupRepository.findById(groupName).isPresent()) {
      throw new NoSuchCodeException();
    }
    groupRepository.delete(groupName);
  }
  /**
   * Modifies the group name
   * 
   * @param groupName name of the group
   * @throws NoSuchCodeException if the original group name does not exist
   * @throws GroupExistsException if the target group name already exist
   */
  public Collection<String> listOfGroups() {
    return groupRepository.findAll().stream()
        .map(Group::getName)
        .sorted()
        .collect(Collectors.toList());
  }

  /**
   * Add a person to a group
   * 
   * @param codePerson person code
   * @param groupName  name of the group
   * @throws NoSuchCodeException in case the code or group name do not exist
   */
  public void addPersonToGroup(String code, String groupName) throws NoSuchCodeException {
    Person person = personRepository.findById(code).orElse(null);
    Group group = groupRepository.findById(groupName).orElse(null);
    if (person == null || group == null) throw new NoSuchCodeException();

    group.getMembers().add(person);
    groupRepository.save(group);
  }
  /**
   * Retrieves the list of people on a group
   * 
   * @param groupName name of the group
   * @return collection of person codes
   */
  public Collection<String> listOfPeopleInGroup(String groupName) {
    Group group = groupRepository.findById(groupName).orElse(null);
    if (group == null) return null;

    return group.getMembers().stream()
        .map(Person::getCode)
        .sorted()
        .collect(Collectors.toList());
  }

  /**
   * Retrieves the code of the person having the largest
   * group of friends
   * 
   * @return the code of the person
   */
  public String personWithLargestNumberOfFriends() {
    return personRepository.findAll().stream()
        .max(Comparator.comparingInt(p -> p.getFriends().size()))
        .map(Person::getCode)
        .orElse(null);
  }

  /**
   * Find the name of group with the largest number of members
   * 
   * @return the name of the group
   */

  public String largestGroup() {
    return groupRepository.findAll().stream()
        .max(Comparator.comparingInt(g -> g.getMembers().size()))
        .map(Group::getName)
        .orElse(null);
  }

  /**
   * Find the code of the person that is member of
   * the largest number of groups
   * 
   * @return the code of the person
   */
  public String personInLargestNumberOfGroups() {
    Map<String, Integer> groupCount = new HashMap<>();
    for (Group group : groupRepository.findAll()) {
      for (Person member : group.getMembers()) {
        groupCount.merge(member.getCode(), 1, Integer::sum);
      }
    }

    return groupCount.entrySet().stream()
        .max(Map.Entry.comparingByValue())
        .map(Map.Entry::getKey)
        .orElse(null);
  }

  // R5

  /**
   * add a new post by a given account
   * 
   * @param authorCode the id of the post author
   * @param text   the content of the post
   * @return a unique id of the post
   */

   public String post(String code, String text) {
    Person person = personRepository.findById(code).orElse(null);
    if (person == null) return null;

    Post post = new Post(person, text);
    postRepository.save(post);
    return post.getId();
  }
  /**
   * retrieves the timestamp of the given post
   * 
   * @param pid    the id of the post
   * @return the timestamp of the post
   */
  public long getTimestamp(String postId) {
    return postRepository.findById(postId)
        .map(Post::getTimestamp)
        .orElse(0L);
  }

  public String getPostContent(String postId) {
    return postRepository.findById(postId)
        .map(Post::getContent)
        .orElse(null);
  }
  /**
   * returns the list of post of a given author paginated
   * 
   * @param author     author of the post
   * @param pageNo     page number (starting at 1)
   * @param pageLength page length
   * @return the list of posts id
   */
  public List<String> getPaginatedUserPosts(String code, int page, int size) {
    Person person = personRepository.findById(code).orElse(null);
    if (person == null) return List.of();

    return postRepository.findAll().stream()
        .filter(p -> p.getAuthor().equals(person))
        .sorted(Comparator.comparing(Post::getTimestamp).reversed())
        .skip((long) (page - 1) * size)
        .limit(size)
        .map(Post::getId)
        .collect(Collectors.toList());
  }
  /**
   * returns the paginated list of post of friends.
   * The returned list contains the author and the id of a post separated by ":"
   * 
   * @param author     author of the post
   * @param pageNo     page number (starting at 1)
   * @param pageLength page length
   * @return the list of posts key elements
   */
  public List<String> getPaginatedFriendPosts(String code, int page, int size) {
    Person person = personRepository.findById(code).orElse(null);
    if (person == null) return List.of();

    Set<Person> friends = person.getFriends();
    return postRepository.findAll().stream()
        .filter(p -> friends.contains(p.getAuthor()))
        .sorted(Comparator.comparing(Post::getTimestamp).reversed())
        .skip((long) (page - 1) * size)
        .limit(size)
        .map(p -> p.getAuthor().getCode() + ":" + p.getId())
        .collect(Collectors.toList());
  }
}
