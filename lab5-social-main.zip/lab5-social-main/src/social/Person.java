package social;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
public class Person {

  @Id
  private String code;
  private String name;
  private String surname;

  @ManyToMany(fetch = FetchType.EAGER)
  @JoinTable(
    name = "friendship",
    joinColumns = @JoinColumn(name = "person_code"),
    inverseJoinColumns = @JoinColumn(name = "friend_code")
  )
  private Set<Person> friends = new HashSet<>();

  
    // default constructor is needed by JPA

  public Person() {}

  public Person(String code, String name, String surname) {
    this.code = code;
    this.name = name;
    this.surname = surname;
  }

  public String getCode() {
    return code;
  }

  String getName() {
    return name;
  }

  public String getSurname() {
    return surname;
  }

  public Set<Person> getFriends() {
    return friends;
  }

public void addFriend(Person p) {
  if (!friends.contains(p)) {
    friends.add(p);
    if (!p.friends.contains(this)) {
      p.friends.add(this);
    }
  }
}

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Person person = (Person) o;
    return Objects.equals(code, person.code);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code);
  }
}
