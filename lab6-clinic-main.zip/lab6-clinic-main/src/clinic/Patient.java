package clinic;

public class Patient {

    String first;
    String last;
    String ssn;

    public Patient(String first, String last, String ssn) {
        this.first = first;
        this.last = last;
        this.ssn = ssn;
    }

    @Override
    public String toString(){
        StringBuffer s = new StringBuffer();
        s.append(last).append(" ").append(first).append(" (").append(ssn).append(")");
        return s.toString();
    }
}
