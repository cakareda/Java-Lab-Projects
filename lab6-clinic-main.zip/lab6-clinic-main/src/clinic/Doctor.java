package clinic;

public class Doctor extends Patient implements Comparable<Doctor>{
    
    int docID;
    String specialization;

    public Doctor(String first, String last, String ssn, int docID, String specialization) {
        super(first, last, ssn);
        this.docID = docID;
        this.specialization = specialization;
    }

    public String toStringNumPat(Integer nPat){
        StringBuffer buf = new StringBuffer();
        return buf.append(String.format("%03d", nPat)).append(" : ").append(docID).append(" ")
            .append(last).append(" ").append(first).toString();
    }

    @Override
    public String toString(){        
        StringBuffer newStr = new StringBuffer();
        newStr.append(" [").append(docID).append("]: ").append(specialization);
        return super.toString().concat(newStr.toString());
    }

    @Override
    public int compareTo(Doctor doc) {
        if (!this.last.equals(doc.last)){
            return this.last.compareTo(doc.last);
        }
        else return this.first.compareTo(doc.first);
    }
}
